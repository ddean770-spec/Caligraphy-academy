package com.inkandflourish

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.*
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

private data class Lesson(val style: String, val title: String, val glyph: String, val hint: String, val strokes: Int)

class MainActivity : Activity() {
    private val lessons = listOf(
        Lesson("Copperplate", "Oval entry · lowercase o", "o", "Build a light oval with a smooth, even curve.", 1),
        Lesson("Copperplate", "Underturn · lowercase i", "i", "Keep the downstroke straight; add the dot afterwards.", 2),
        Lesson("Copperplate", "Compound curve · lowercase n", "n", "Aim for two even minims with a gentle exit hairline.", 1),
        Lesson("Modern", "Modern lowercase a", "a", "Relax the shape. Modern calligraphy allows personal variation.", 1),
        Lesson("Italic", "Italic lowercase a", "a", "Use a consistent forward slant and a compact oval.", 1),
        Lesson("Gothic", "Blackletter basic stem", "ı", "Practise a firm vertical stem before adding diamond details.", 1),
        Lesson("Flourishing", "Entry and exit swash", "~", "Keep the movement light, spacious and controlled.", 1)
    )
    private var index = 0
    private lateinit var board: PracticeView
    private lateinit var title: TextView
    private lateinit var style: TextView
    private lateinit var hint: TextView
    private lateinit var score: TextView
    private lateinit var progress: TextView
    private var completed = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        completed = getPreferences(0).getInt("completed", 0)
        buildScreen()
        showLesson()
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(14), dp(18), dp(12))
            setBackgroundColor(Color.rgb(16, 24, 32))
        }
        val brand = TextView(this).apply {
            text = "INK  &  FLOURISH"
            textSize = 12f; letterSpacing = .22f; setTextColor(Color.rgb(201,166,107)); gravity = Gravity.CENTER
        }
        root.addView(brand, LinearLayout.LayoutParams(-1, dp(28)))
        title = TextView(this).apply { textSize = 25f; typeface = Typeface.SERIF; setTextColor(Color.WHITE); gravity = Gravity.CENTER; setPadding(0, dp(4), 0, dp(2)) }
        root.addView(title, LinearLayout.LayoutParams(-1, dp(42)))
        style = TextView(this).apply { textSize = 12f; setTextColor(Color.rgb(201,166,107)); gravity = Gravity.CENTER }
        root.addView(style, LinearLayout.LayoutParams(-1, dp(24)))
        hint = TextView(this).apply { textSize = 14f; setTextColor(Color.rgb(205,211,215)); gravity = Gravity.CENTER; setPadding(dp(8), dp(4), dp(8), dp(8)) }
        root.addView(hint, LinearLayout.LayoutParams(-1, dp(48)))

        board = PracticeView(this)
        val boardParams = LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(8); bottomMargin = dp(10) }
        root.addView(board, boardParams)

        score = TextView(this).apply { text = "Your feedback will appear here after you write"; textSize = 13f; setTextColor(Color.rgb(201,166,107)); gravity = Gravity.CENTER; setPadding(dp(4), dp(6), dp(4), dp(6)) }
        root.addView(score, LinearLayout.LayoutParams(-1, dp(44)))
        progress = TextView(this).apply { textSize = 11f; setTextColor(Color.LTGRAY); gravity = Gravity.CENTER }
        root.addView(progress, LinearLayout.LayoutParams(-1, dp(22)))

        val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        row1.addView(actionButton("Styles / lessons") { chooseLesson() }, weighted())
        row1.addView(actionButton("Clear") { board.clear(); score.text = "Canvas cleared — have another go." }, weighted())
        root.addView(row1)
        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        row2.addView(actionButton("Check my writing") { assess() }, weighted())
        row2.addView(actionButton("Next lesson  →") { index = (index + 1) % lessons.size; showLesson() }, weighted())
        root.addView(row2)
        setContentView(root)
    }

    private fun showLesson() {
        val l = lessons[index]
        title.text = l.title
        style.text = "${l.style.uppercase()}  •  LESSON ${index + 1} OF ${lessons.size}"
        hint.text = l.hint
        board.setLesson(l)
        score.text = "Write with your S Pen, then tap Check my writing."
        progress.text = "$completed practice checks saved on this device"
    }

    private fun assess() {
        val result = board.assess()
        score.text = result
        if (board.strokeCount > 0) {
            completed++
            getPreferences(0).edit().putInt("completed", completed).apply()
            progress.text = "$completed practice checks saved on this device"
        }
    }

    private fun chooseLesson() {
        val names = lessons.map { "${it.style} — ${it.title}" }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Choose a lesson")
            .setItems(names) { _, which -> index = which; showLesson() }
            .setNegativeButton("Cancel", null).show()
    }

    private fun actionButton(label: String, click: () -> Unit): Button = Button(this).apply {
        text = label; textSize = 12f; isAllCaps = false; setTextColor(Color.WHITE)
        setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(42, 55, 65)))
        setOnClickListener { click() }
        setPadding(dp(8), dp(5), dp(8), dp(5))
    }
    private fun weighted() = LinearLayout.LayoutParams(0, dp(48), 1f).apply { setMargins(dp(4), dp(3), dp(4), dp(3)) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}

private class PracticeView(context: Context) : View(context) {
    private val ink = Paint(Paint.ANTI_ALIAS_FLAG)
    private val guide = Paint(Paint.ANTI_ALIAS_FLAG)
    private val grid = Paint(Paint.ANTI_ALIAS_FLAG)
    private val strokes = mutableListOf<MutableList<Sample>>()
    private var active: MutableList<Sample>? = null
    private var lesson = Lesson("Copperplate", "Oval", "o", "", 1)
    private var averagePressure = 0f
    private var pressureSamples = 0
    var strokeCount = 0
        private set

    private data class Sample(val x: Float, val y: Float, val pressure: Float, val time: Long)

    init {
        setLayerType(View.LAYER_TYPE_SOFTWARE, null)
        ink.color = Color.rgb(238, 231, 216); ink.style = Paint.Style.STROKE; ink.strokeCap = Paint.Cap.ROUND; ink.strokeJoin = Paint.Join.ROUND
        guide.color = Color.argb(100, 201, 166, 107); guide.textAlign = Paint.Align.CENTER; guide.typeface = Typeface.create("serif", Typeface.ITALIC)
        grid.color = Color.argb(65, 201, 166, 107); grid.strokeWidth = 1f
    }

    fun setLesson(l: Lesson) { lesson = l; clear() }
    fun clear() { strokes.clear(); active = null; strokeCount = 0; averagePressure = 0f; pressureSamples = 0; invalidate() }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(Color.rgb(247, 244, 235))
        val left = width * .08f; val right = width * .92f
        val top = height * .18f; val baseline = height * .72f; val xheight = height * .49f; val asc = height * .22f
        grid.strokeWidth = 1f
        canvas.drawLine(left, asc, right, asc, grid)
        canvas.drawLine(left, xheight, right, xheight, grid)
        canvas.drawLine(left, baseline, right, baseline, grid)
        canvas.drawLine(left, height * .88f, right, height * .88f, grid)
        guide.textSize = min(width, height) * .55f
        guide.alpha = 105
        canvas.drawText(lesson.glyph, width * .5f, baseline, guide)
        val p = Paint(ink)
        strokes.forEach { drawStroke(canvas, it, p) }
        active?.let { drawStroke(canvas, it, p) }
        val label = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(116, 108, 93); textSize = 12f; textAlign = Paint.Align.CENTER }
        canvas.drawText("ASCENDER", width/2f, asc - 9f, label)
        canvas.drawText("X-HEIGHT", width/2f, xheight - 9f, label)
        canvas.drawText("BASELINE", width/2f, baseline + 20f, label)
    }

    private fun drawStroke(canvas: Canvas, samples: List<Sample>, paint: Paint) {
        if (samples.isEmpty()) return
        if (samples.size == 1) {
            val s = samples[0]; paint.style = Paint.Style.FILL; paint.strokeWidth = 2f + s.pressure * 3f; canvas.drawCircle(s.x, s.y, paint.strokeWidth/2f, paint); paint.style = Paint.Style.STROKE; return
        }
        for (i in 1 until samples.size) {
            val a = samples[i-1]; val b = samples[i]
            paint.strokeWidth = 1.5f + (a.pressure + b.pressure) * 2.4f
            canvas.drawLine(a.x, a.y, b.x, b.y, paint)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        // Prioritise the S Pen. Finger input remains enabled as an accessibility fallback.
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                if (event.actionIndex != 0 && event.getToolType(event.actionIndex) != MotionEvent.TOOL_TYPE_STYLUS) return true
                active = mutableListOf()
                addSample(event, event.actionIndex)
                parent?.requestDisallowInterceptTouchEvent(true)
                invalidate(); return true
            }
            MotionEvent.ACTION_MOVE -> {
                val a = active ?: return true
                for (h in 0 until event.historySize) {
                    val x = event.getHistoricalX(0, h); val y = event.getHistoricalY(0, h)
                    val pr = event.getHistoricalPressure(0, h).coerceIn(.05f, 1f)
                    a.add(Sample(x, y, pr, event.getHistoricalEventTime(h)))
                }
                addSample(event, 0); invalidate(); return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> {
                active?.let { if (it.isNotEmpty()) { strokes.add(it); strokeCount = strokes.size; it.forEach { s -> averagePressure += s.pressure; pressureSamples++ }; } }
                active = null; parent?.requestDisallowInterceptTouchEvent(false); invalidate(); return true
            }
            MotionEvent.ACTION_CANCEL -> { active = null; parent?.requestDisallowInterceptTouchEvent(false); invalidate(); return true }
        }
        return true
    }

    private fun addSample(e: MotionEvent, index: Int) {
        val a = active ?: return
        val x = e.getX(index); val y = e.getY(index)
        val pr = if (e.getToolType(index) == MotionEvent.TOOL_TYPE_STYLUS) e.getPressure(index).coerceIn(.05f, 1f) else .45f
        a.add(Sample(x, y, pr, e.eventTime))
    }

    fun assess(): String {
        if (strokes.isEmpty()) return "No strokes yet — trace the guide with your S Pen first."
        val pts = strokes.flatten()
        val minX = pts.minOf { it.x }; val maxX = pts.maxOf { it.x }
        val minY = pts.minOf { it.y }; val maxY = pts.maxOf { it.y }
        val boxW = max(1f, maxX-minX); val boxH = max(1f, maxY-minY)
        val pathLength = strokes.sumOf { s -> s.zipWithNext().sumOf { pair -> kotlin.math.hypot((pair.second.x-pair.first.x).toDouble(), (pair.second.y-pair.first.y).toDouble()) } }.toFloat()
        val smoothness = (pts.size.toFloat() / max(1f, pathLength / 8f)).coerceIn(0f, 1f)
        val pressure = if (pressureSamples > 0) averagePressure / pressureSamples else .45f
        val feedback = mutableListOf<String>()
        if (boxW < width * .12f || boxH < height * .12f) feedback.add("Make the letter larger so its proportions are easier to control.")
        else feedback.add("Good: you're using a clear writing area.")
        if (abs(boxW / boxH - 0.72f) > .75f) feedback.add("Check the letter's width-to-height ratio against the pale guide.") else feedback.add("Your overall proportions are in a useful range.")
        if (smoothness < .35f) feedback.add("Try slower, more continuous strokes with less stopping.") else feedback.add("Your stroke path looks reasonably continuous.")
        if (pressure > .78f) feedback.add("Ease off the pressure; aim for a lighter touch.") else feedback.add("Your pressure is not excessively heavy.")
        feedback.add("Practice score: ${(35 + smoothness*25 + (1f-abs(pressure-.45f))*25 + min(15f, pts.size/8f)).toInt().coerceIn(0,100)}/100 (early estimate)")
        return feedback.joinToString("  •  ")
    }
}
